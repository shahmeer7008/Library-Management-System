
public class reviews {
   
    String username; 
    String BookName; 
    String review; 
    public reviews(String n, String a, String pn) { 
        username = n; 
        BookName = a; 
        review = pn; 
    } 
    
}

