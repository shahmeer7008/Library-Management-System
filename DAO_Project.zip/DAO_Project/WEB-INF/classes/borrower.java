


public class borrower {
   
    String username; 
    String BookName; 
    String BorrowDate; 
    String DueDate; 
    public borrower(String n, String a,String b, String pn) { 
        username = n; 
        BookName=a;
        BorrowDate = b; 
        DueDate= pn; 
    } 
   
    
}


