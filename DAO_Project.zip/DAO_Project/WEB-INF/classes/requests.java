
public class requests {
   
    String username; 
    String BookName; 
    String status; 
    public requests(String n, String a, String pn) { 
        username = n; 
        BookName = a; 
        status = pn; 
    } 
    
}

