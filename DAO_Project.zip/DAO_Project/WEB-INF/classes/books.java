

public class books {
   
    String BookName; 
    String Author; 
    String BookStatus; 
    public books(String n, String a,String B) { 
        BookName = n; 
        Author = a; 
        BookStatus=B; 
    } 
    
}
