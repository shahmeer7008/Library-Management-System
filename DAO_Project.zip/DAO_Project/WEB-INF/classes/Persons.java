public class Persons {
   
        String username; 
        String password; 
        String role; 
        public Persons(String n, String a, String pn) { 
            username = n; 
            password = a; 
            role = pn; 
        } 
        
}
